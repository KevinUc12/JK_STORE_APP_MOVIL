# JK_STORE_APP_MOVIL
Version 1.0.0

Descripcion
---------
Una apliacion movil, basado en un proyecto web, se trata de un punto de venta donde se podra realizar compras y registro de cada pruducto

-------
INTEGRANTES
--------
UC DZIB KEVIN ANTONIO

XOOL ALVAREZ JARED ALBERTO
-----------------

TECNOLOGIA A USAR
-----------

FLUTTER // LENGUAJE DART

BASE DE DATOS POR DECIDIRSE
